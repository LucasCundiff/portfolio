from django.contrib import admin
from .models import Skill
from .models import Project
# Register your models here.

admin.site.register(Skill)
admin.site.register(Project)