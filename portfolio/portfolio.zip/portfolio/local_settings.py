secret_key = 'django-insecure-0%=7oriaskn%9i(o9&sp3-x-2_b^ywo0c(^4up0kf^he^(sm=s'
allowed_hosts = ["www.lrcshowcase.com", "lrcshowcase.us-east-2.elasticbeanstalk.com", "lrcshowcase.com", "127.0.0.1"]
rds_name = 'postgres'
rds_username = 'lcundiff9'
rds_password = 'Pix3l4rt!12'
rds_host = 'website-db.cuzjen4ze58c.us-east-2.rds.amazonaws.com'
rds_port = '5432'