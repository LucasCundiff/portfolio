secret_key = 'django-insecure-0%=7oriaskn%9i(o9&sp3-x-2_b^ywo0c(^4up0kf^he^(sm=s'
allowed_hosts = ["www.lrcshowcase.com", "lrcshowcase.us-east-2.elasticbeanstalk.com", "lrcshowcase.com", "127.0.0.1"]